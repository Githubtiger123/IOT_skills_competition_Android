/* Includes ------------------------------------------------------------------*/
#include "timer_handles.h"
#include "key_scaner.h"

void Time2Handler(){
	keyScanner();
}

void Time3Handler(){
}
