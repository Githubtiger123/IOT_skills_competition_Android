/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  */
#include <string.h>
#include "board.h"
#include "hal_key.h"
#include "tim-board.h"
#include "timer_handles.h"
#include "key_scaner.h"
#include "sht1x.h"         // controller register definitions 
#include "sht3x.h"
#include "adc_reader.h"
#include "math.h"
#include "hal_oled.h"
#include "usart1-board.h"
#include "utilities.h"

float temp,hum,LightLux;
unsigned char data[40];
unsigned int Timer_Count = 0;
void My_Time2Handler(){
	//keyScanner();
	Timer_Count++;
	if(Timer_Count>300){
	
		call_sht11(&temp,&hum);
		AdcScanChannel();
		LightLux = pow(10, ((1.78 - log10(33 / AdcReadCh0() - 10)) / 0.6)); 
		Timer_Count = 0;
	}
}


/**********************************************************************************************
*������void Init( void )
*���ܣ�ƽ̨��ʼ��
*���룺��
*�������
*����˵������
**********************************************************************************************/
void Init() {
    // ������ƽ̨��ʼ��
    BoardInitMcu();
    BoardInitPeriph();
    keys_init();//������ʼ��
    setTimer2Callback(My_Time2Handler);
    Tim2McuInit(1);//��ʱ����ʼ�������ö�ʱ�ж�1ms�ж�һ��
	 SHTXX_Init();
	ADCS_Init();
	OLED_Init();
	USART1_Init(115200);
}

void initView(){

	OLED_ShowCHinese(32+16*0,0,0);OLED_ShowCHinese(32+16*1,0,1);OLED_ShowCHinese(32+16*2,0,2);OLED_ShowCHinese(32+16*3,0,3);
	OLED_ShowCHinese(0,2,22);OLED_ShowCHinese(16*1,2,23);OLED_ShowCHinese(32+16*2 - 8,2,4);
	OLED_ShowCHinese(6*0,4,24);OLED_ShowCHinese(16*1,4,23);//OLED_ShowString(32+16*3,4,"%");
	OLED_ShowCHinese(6*0,6,29);OLED_ShowCHinese(16*1,6,30);//OLED_ShowString(40+16*4,6,"lux");
}

/**********************************************************************************************
*������void KeyDownHandler( void )
*���ܣ���ť�¼�����
*���룺��
*�������
*����˵������
**********************************************************************************************/
void KeyDownHandler(void) {
	
}

/**********************************************************************************************
*������void handlerPre10Ms( void )
*���ܣ�10����ѭ��
*���룺��
*�������
*����˵����ѭ��������ʱ��300ms
**********************************************************************************************/
void handlerPre10Ms(void) {
    for (int delay = 0; delay < 30; delay++) {
        HAL_Delay(10);
        
    }
}



/**
 * Main application entry point.
 */
int main( void )
{
    Init();
	initView();
    while( 1 )
    {
			sprintf(data,"%2d",(int)temp);
			OLED_ShowString(40,2,data);
			sprintf(data,"%2d%% ",(int)hum);
			OLED_ShowString(40,4,data);
			sprintf(data,"%4dlux ",(int)LightLux);
			OLED_ShowString(40,6,data);
			
			if(HAL_GPIO_ReadPin(KEY2_GPIO, KEY2_GPIO_PIN)==0){
			
				sprintf(data,"temperature(��):%2.2f|humidity(%%):%2.2f",temp,hum);
				unsigned char d[strlen(data)*3];
				memset(d,0,sizeof(d));
				int i;
				for(i=0;i<strlen(data);i++){
				
					d[i*3+0] = Nibble2HexChar((data[i] & 0xf0) >> 4); //�пӣ�ע�����ȼ�˳��
					d[i*3+1] = Nibble2HexChar(data[i]&0x0f);
					d[i*3+2] = ' ';
				}
				USART1_SendStr(d,strlen(d));
				GpioWrite(&Led1,0);
			}else{
				sprintf(data,"temperature(��):%2.2f|humidity(%%):%2.2f",temp,hum);
				USART1_SendStr(data,strlen(data));
				GpioWrite(&Led1,1);
			}
			HAL_Delay(100);
		}
}
