/* Includes ------------------------------------------------------------------*/

#ifndef __KEY_SCANNER_H
#define __KEY_SCANNER_H

#include "stm32l1xx_hal.h"
#include "board.h"

#ifdef __cplusplus
extern "C" {
#endif

void keyScanner(void);
	
#ifdef __cplusplus
}
#endif

#endif /* __KEY_SCANNER_H */


